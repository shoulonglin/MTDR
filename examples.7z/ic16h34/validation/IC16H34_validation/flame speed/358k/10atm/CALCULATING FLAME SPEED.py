import cantera as ct
import time


def cal_speed_flame(gas_func, T0_func, P0_func, phi_func, fuel_func, oxidizer_func):
    """
    calculate speed flame at specified condition
    :param oxidizer_func: burning oxidizer
    :param fuel_func: burning fuel
    :param gas_func:gas object needed calculation
    :param T0_func:initial T
    :param P0_func:initial P
    :param phi_func:simulation phi
    :return:flame speed
    """
    gas_func.TP = T0_func, P0_func
    gas_func.set_equivalence_ratio(phi_func, fuel_func, oxidizer_func)
    flame_func = ct.FreeFlame(gas_func, width=0.014)
    flame_func.set_refine_criteria(ratio=3, slope=0.2, curve=0.1)
    flame_func.solve(loglevel=1, auto=False)
    flame_speed_func = flame_func.u[0]

    return flame_speed_func

t0 = time.time()
gas = ct.Solution('rd_mech.cti')
flame_speed = []
phi = [0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4]
for sim_phi in phi:
    gas_flame_speed = cal_speed_flame(gas, 358, 101325*10, sim_phi, 'IC16H34', 'O2:1.0, N2:3.76')
    flame_speed.append(gas_flame_speed)
t1 = time.time()
print(t1-t0)
print('flame speed is')
print(flame_speed)
with open('./flame_speed_rd_mech.csv', 'w') as f:
    for i in range(len(flame_speed)):
        f.write(str(phi[i]))
        f.write(',')
        f.write(str(flame_speed[i]))
        f.write('\n')