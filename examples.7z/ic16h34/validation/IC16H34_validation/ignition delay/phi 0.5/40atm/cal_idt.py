# !/usr/bin/env python
# encoding: utf-8
"""
@Project: new_manifold_projection
@Time: 2021/7/16 16:46
@Author: caozheng
@File: start_reduction2.0.py
@Idea: PyCharm
"""
import time
import cantera as ct


def input_data(file_name='input.txt'):
    """
    解析输入文件
    :param file_name: 输入文件的路径
    :return: 返回解析后的一个包含缩减机理所需要的数据的元组
    """
    with open(file_name) as f_func:
        contents_func = f_func.readlines()

    mechanism_name_func = contents_func[0].split(':')[1].strip()

    T_func = []
    b_func = contents_func[1].split(':')[1].strip().replace(' ', '')[1:-1].split(',')
    for b_1 in b_func:
        T_func.append(float(b_1))

    sim_pressure_func = float(contents_func[2].split(':')[1].strip())

    sim_phi_func = float(contents_func[3].split(':')[1].strip())

    fuel_func = contents_func[4].strip().replace(' ', '')[5:]

    oxidizer_func = contents_func[5].strip().replace(' ', '')[9:]

    error_func = float(contents_func[6].split(':')[1].strip())

    important_sp_func = contents_func[7].split(':')[1].strip()[1:-1].replace(' ', '').split(',')

    mark_func = ',' in fuel_func

    return mechanism_name_func, T_func, sim_pressure_func, sim_phi_func, fuel_func, oxidizer_func, error_func, important_sp_func, mark_func


def calculate_ignition_delay(gas_func, gas_state_func, phi_func, fuel_func, oxidizer_func, estimated_ig_func=200):
    """
    calculate ignition delay
    :param estimated_ig_func: estimated ignition delay time,if no detailed mech data, set to 0.1. otherwise set to detailed data
    :param gas_func: the gas solution
    :param gas_state_func: state of simulation
    :param phi_func: equivalence ratio
    :param fuel_func: fuel
    :param oxidizer_func: oxidizer
    :return: ignition delay
    """
    gas_func.TP = gas_state_func
    gas_func.set_equivalence_ratio(phi=phi_func, fuel=fuel_func, oxidizer=oxidizer_func)
    r_func = ct.IdealGasConstPressureReactor(gas_func)
    r_net = ct.ReactorNet([r_func])
    time_history = ct.SolutionArray(gas_func, extra="t")

    estimated_ignition_delay_time_func = estimated_ig_func
    t_func = 0
    count_func = 1
    while t_func < estimated_ignition_delay_time_func:
        t_func = r_net.step()
        time_history.append(r_func.thermo.state, t=t_func)
        count_func += 1
    temperature = time_history.T
    temperature_list = list(temperature)
    time = time_history.t
    time_list = list(time)
    ig_delay_func = 0
    for temperature_point in temperature_list:
        if temperature_point >= gas_state_func[0] + 400:
            index_T = temperature_list.index(temperature_point)
            ig_delay_func = time_list[index_T]
            break

    return ig_delay_func


def calculate_ignition_delay_and_max_error(T_func, gas_func, pressure_func, phi_func, fuel_func,
                                           oxidizer_func, detailed_mech_ignition_delay_func=[]):
    """
    计算最大的着火延迟误差
    :param T_func: 温度列表
    :param gas_func: gas对象
    :param pressure_func: 压力值
    :param phi_func: 当量比
    :param fuel_func: 燃料组成
    :param oxidizer_func: 氧化剂组成
    :param detailed_mech_ignition_delay_func:详细机理在各温度点的着火延迟
    :return: 缩减机理在各温度点的着火延迟  和   缩减机理的最大相对误差
    """
    ignition_delay_at_t_func = []
    for t_func in T_func:
        ig_func = calculate_ignition_delay(gas_func, (t_func, pressure_func), phi_func, fuel_func, oxidizer_func)
        ignition_delay_at_t_func.append(ig_func)

    if not detailed_mech_ignition_delay_func:
        return ignition_delay_at_t_func

    else:
        ignition_delay_error_list_func = []
        for ii_func in range(len(T_func)):
            ignition_delay_error_list_func.append(
                abs((detailed_mech_ignition_delay_func[ii_func] - ignition_delay_at_t_func[ii_func])
                    / detailed_mech_ignition_delay_func[ii_func]))
        test_error_func = max(ignition_delay_error_list_func)

        return ignition_delay_at_t_func, test_error_func


if __name__ == '__main__':
    start_reduction = time.time()
    input_data_tuple = input_data()
    gas_name = input_data_tuple[0]
    gas = ct.Solution(input_data_tuple[0])
    T = input_data_tuple[1]
    sim_pressure = ct.one_atm * input_data_tuple[2]
    sim_phi = input_data_tuple[3]
    gas_fuel = input_data_tuple[4]
    gas_oxidizer = input_data_tuple[5]
    error_limit = input_data_tuple[6]
    important_species = input_data_tuple[7]
    mark = input_data_tuple[8]
    length = len(gas.species())

    # calculating ignition delay at given temperature point
    start_cal_ig = time.time()
    detailed_mech_ignition_delay_list = calculate_ignition_delay_and_max_error(T, gas, sim_pressure, sim_phi, gas_fuel,
                                                                               gas_oxidizer)
    end_cal_ig = time.time()
    # write detailed mechanism ignition delay data to output_data.csv
    with open('output_data.csv', 'w') as f:
        f.write('ignition delay at given temperature point：\n')
    with open('output_data.csv', 'a') as f:
        for i in range(len(T)):
            f.write(f'{T[i]},{detailed_mech_ignition_delay_list[i]}\n')
    with open('output_data.csv', 'a') as f:
        f.write('\n')
